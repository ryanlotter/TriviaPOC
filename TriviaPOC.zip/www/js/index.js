function QuizList($scope) {
    
    
    
}